// FTPEventSink.cpp: implementation of the CFTPEventSink class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ftpserver.h"
#include "FTPEventSink.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFTPEventSink::CFTPEventSink()
{

}

CFTPEventSink::~CFTPEventSink()
{

}
